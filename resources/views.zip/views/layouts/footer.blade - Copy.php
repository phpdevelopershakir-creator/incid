<footer class="main-footer">

    <strong>Copyright &copy; 2024 <a href="https://mhapsd.gov.bd/">Public Security Division (PSD), Ministry of Home Affairs, Bangladesh
</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
 
    </div>
  </footer>