<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ThirtyNine extends Model
{
    use HasFactory;

    protected $table ='victims_restitution_q39';
}