<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TwentySeven extends Model
{
    use HasFactory;

    protected $table ='government_direct_victim_q27';
}